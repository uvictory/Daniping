(function () {
  try {
      // 현재 inject.js 는 이미 타겟 프레임 내에서 실행되므로, 굳이 frame 탐색 없이 window 직접 접근
    const target = window;  // inject.js는 주입된 프레임에서 실행되므로, 해당 프레임의 window 자체
      // 기존 notifyDebug 함수를 보존 (원본 함수)
    const original = target.notifyDebug;
        // notifyDebug가 함수로 정의되어 있는 경우에만 후킹 시도
    if (typeof original === 'function') {
        // NotifyDebug를 재정의: 감지된 알림을 콘솔에 출력하고, 서버로 전송한 후 원래 함수 호출
      target.notifyDebug = function (data) {
          // 감지된 알림 출력
        console.log("📥 감지된 알림:", data);

        // WebSocket 서버 대신 HTTP POST 요청으로 감지된 알림 전송
        fetch("http://127.0.0.1:9090", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type: "notify", content: data })
        }).catch(err => console.warn("❌ WebSocket 전송 실패:", err));

           // 🔁 원래 notifyDebug 함수도 계속 호출되도록 함
        return original.apply(this, arguments);
      };

      console.log("✅ webNotifyProcess 후킹 성공!");
    } else {
      console.log("⚠️ webNotifyProcess 없음 (정의되지 않음)");
    }
  } catch (err) {
    console.error("⛔ 후킹 중 오류 발생:", err);
  }
})();
