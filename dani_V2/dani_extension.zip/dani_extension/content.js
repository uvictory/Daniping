
let ws = new WebSocket("ws://127.0.0.1:9999");  // 서버 주소 고정

ws.onopen = () => console.log("✅ WebSocket 연결됨");
ws.onerror = (err) => console.error("❌ WebSocket 오류", err);


function getInternalIP() {
  return new Promise((resolve) => {
    const pc = new RTCPeerConnection({ iceServers: [] });
    pc.createDataChannel('');
    pc.createOffer().then(offer => pc.setLocalDescription(offer));

    pc.onicecandidate = event => {
      if (!event || !event.candidate) return;

      const ipMatch = /([0-9]{1,3}(\.[0-9]{1,3}){3})/.exec(event.candidate.candidate);
      if (ipMatch) {
        resolve(ipMatch[1]); // ✅ 내부 IP 주소
        pc.close();
      }
    };
  });
}

// ✅ WebSocket 초기화 + 연결 완료될 때까지 대기
async function connectWebSocket() {
  return new Promise((resolve, reject) => {
    ws = new WebSocket("ws://127.0.0.1:9999");  // 서버 IP로

    ws.onopen = () => {
      console.log("✅ WebSocket 연결됨");
      resolve();
    };

    ws.onerror = (err) => {
      console.error("❌ WebSocket 오류:", err);
      reject(err);
    };
  });
}

// ✅ 서버에 알람 전송
async function sendAlarmToServer(alarmData) {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        console.warn("! websocket 연결이 없거나 IP 없음");
        return;
    }

    const payload = {
      ...alarmData // sender, subject, notifytype 등 포함
    };

    ws.send(JSON.stringify(payload));
    console.log("📤 서버로 전송:", payload);
}

function injectScriptFileToFrame(frame) {
  try {
    const script = frame.document.createElement('script');
    script.src = chrome.runtime.getURL('inject.js');  // 확장 내 리소스 경로
    script.onload = () => script.remove(); // 로드 후 제거
    frame.document.documentElement.appendChild(script);
    console.log("✅ inject.js 삽입 성공");
  } catch (e) {
    console.warn("❌ inject 실패:", e);
  }
}

function waitAndInject() {
  let retries = 0;
  const maxRetries = 30;

  const interval = setInterval(() => {
    try {
      for (let i = 0; i < window.frames.length; i++) {
        const frame = window.frames[i];
        if (frame.document && frame.document.readyState === "complete") {
          injectScriptFileToFrame(frame);
          clearInterval(interval);
          return;
        }
      }
    } catch (e) {
      console.warn("❌ 프레임 접근 실패:", e);
    }

    if (++retries >= maxRetries) {
      clearInterval(interval);
      console.warn("⛔ 프레임 접근 제한: inject 중단");
    }
  }, 1000);
}

waitAndInject();

// ✅ 전체 실행 흐름
async function main() {
  try {
    await connectWebSocket();

  } catch (err) {
    console.error("❌ 실행 중 오류:", err);
  }
}

main();
