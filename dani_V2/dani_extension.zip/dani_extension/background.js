// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("✅ Dani 확장 백그라운드 서비스 워커 실행됨");
});